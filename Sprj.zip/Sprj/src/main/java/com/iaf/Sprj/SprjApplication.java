package com.iaf.Sprj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprjApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprjApplication.class, args);
	}

}
