package com.iaf.Sprj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprjApplicationTests {

	@Test
	void contextLoads() {
	}

}
