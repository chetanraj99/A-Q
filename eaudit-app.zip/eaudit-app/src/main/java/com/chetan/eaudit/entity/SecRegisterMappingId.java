package com.chetan.eaudit.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

/**
 * Composite key for EMMS_EAUDIT_SEC_RGSTR_MPNG_TB.
 * The original screenshots only showed the @EmbeddedId field name (id), not this
 * class's own contents, so this is a reasonable reconstruction (RGSTR_ID + a
 * section code) rather than a verbatim copy — adjust the second column name/type
 * to match your real key if it differs.
 */
@Embeddable
public class SecRegisterMappingId implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "RGSTR_ID", length = 30)
    private String rgstrId;

    @Column(name = "SEC_ID", length = 30)
    private String secId;

    public SecRegisterMappingId() {}

    public SecRegisterMappingId(String rgstrId, String secId) {
        this.rgstrId = rgstrId;
        this.secId = secId;
    }

    public String getRgstrId() { return this.rgstrId; }
    public void setRgstrId(String rgstrId) { this.rgstrId = rgstrId; }

    public String getSecId() { return this.secId; }
    public void setSecId(String secId) { this.secId = secId; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SecRegisterMappingId)) return false;
        SecRegisterMappingId that = (SecRegisterMappingId) o;
        return Objects.equals(rgstrId, that.rgstrId) && Objects.equals(secId, that.secId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(rgstrId, secId);
    }
}
