package com.chetan.eaudit.repository;

import com.chetan.eaudit.entity.ChecklistMapEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ChecklistMapRepository extends JpaRepository<ChecklistMapEntity, Integer> {

    List<ChecklistMapEntity> findByRegister_RgstrId(String rgstrId);
}
