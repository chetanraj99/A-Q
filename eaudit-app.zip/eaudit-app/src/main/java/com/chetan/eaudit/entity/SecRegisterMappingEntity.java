package com.chetan.eaudit.entity;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "EMMS_EAUDIT_SEC_RGSTR_MPNG_TB", schema = "EAUDIT")
public class SecRegisterMappingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private SecRegisterMappingId id;

    @Column(name = "UNIT")
    private String unitDetail;

    @Column(name = "CREATED_ON")
    private long createdOn;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @ManyToOne
    @JoinColumn(name = "RGSTR_ID", insertable = false, updatable = false)
    private RegisterEntity register;

    public SecRegisterMappingId getId() { return this.id; }
    public void setId(SecRegisterMappingId id) { this.id = id; }

    public String getUnitDetail() { return this.unitDetail; }
    public void setUnitDetail(String unitDetail) { this.unitDetail = unitDetail; }

    public String getCreatedBy() { return this.createdBy; }
    public void setCreatedBy(String createdBy) { this.createdBy = createdBy; }

    public long getCreatedOn() { return this.createdOn; }
    public void setCreatedOn(long createdOn) { this.createdOn = createdOn; }

    public RegisterEntity getRegister() { return this.register; }
    public void setRegister(RegisterEntity register) { this.register = register; }
}
