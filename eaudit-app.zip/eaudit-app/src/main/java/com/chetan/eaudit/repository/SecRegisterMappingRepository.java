package com.chetan.eaudit.repository;

import com.chetan.eaudit.entity.SecRegisterMappingEntity;
import com.chetan.eaudit.entity.SecRegisterMappingId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SecRegisterMappingRepository extends JpaRepository<SecRegisterMappingEntity, SecRegisterMappingId> {

    List<SecRegisterMappingEntity> findByRegister_RgstrId(String rgstrId);
}
