package com.chetan.eaudit.controller;

import com.chetan.eaudit.entity.RegisterEntity;
import com.chetan.eaudit.service.RegisterService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/registers")
public class RegisterController {

    private final RegisterService registerService;

    public RegisterController(RegisterService registerService) {
        this.registerService = registerService;
    }

    @PostMapping
    public ResponseEntity<RegisterEntity> create(@Valid @RequestBody RegisterEntity register) {
        return new ResponseEntity<>(registerService.create(register), HttpStatus.CREATED);
    }

    @PutMapping("/{rgstrId}")
    public ResponseEntity<RegisterEntity> update(@PathVariable String rgstrId, @Valid @RequestBody RegisterEntity register) {
        return ResponseEntity.ok(registerService.update(rgstrId, register));
    }

    @GetMapping("/{rgstrId}")
    public ResponseEntity<RegisterEntity> getById(@PathVariable String rgstrId) {
        return ResponseEntity.ok(registerService.getById(rgstrId));
    }

    @GetMapping
    public ResponseEntity<List<RegisterEntity>> getAll() {
        return ResponseEntity.ok(registerService.getAll());
    }

    @DeleteMapping("/{rgstrId}")
    public ResponseEntity<Void> delete(@PathVariable String rgstrId) {
        registerService.delete(rgstrId);
        return ResponseEntity.noContent().build();
    }
}
