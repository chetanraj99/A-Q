package com.chetan.eaudit.service;

import com.chetan.eaudit.entity.ChecklistMapEntity;

import java.util.List;

public interface ChecklistMapService {

    ChecklistMapEntity create(String rgstrId, ChecklistMapEntity checklist);

    ChecklistMapEntity update(int rgstrChklstId, ChecklistMapEntity checklist);

    ChecklistMapEntity getById(int rgstrChklstId);

    List<ChecklistMapEntity> getByRegisterId(String rgstrId);

    void delete(int rgstrChklstId);
}
