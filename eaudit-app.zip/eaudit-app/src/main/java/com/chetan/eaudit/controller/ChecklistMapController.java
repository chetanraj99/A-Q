package com.chetan.eaudit.controller;

import com.chetan.eaudit.entity.ChecklistMapEntity;
import com.chetan.eaudit.service.ChecklistMapService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/registers/{rgstrId}/checklist-items")
public class ChecklistMapController {

    private final ChecklistMapService checklistMapService;

    public ChecklistMapController(ChecklistMapService checklistMapService) {
        this.checklistMapService = checklistMapService;
    }

    @PostMapping
    public ResponseEntity<ChecklistMapEntity> create(@PathVariable String rgstrId,
                                                       @Valid @RequestBody ChecklistMapEntity checklist) {
        return new ResponseEntity<>(checklistMapService.create(rgstrId, checklist), HttpStatus.CREATED);
    }

    @PutMapping("/{rgstrChklstId}")
    public ResponseEntity<ChecklistMapEntity> update(@PathVariable String rgstrId,
                                                       @PathVariable int rgstrChklstId,
                                                       @Valid @RequestBody ChecklistMapEntity checklist) {
        return ResponseEntity.ok(checklistMapService.update(rgstrChklstId, checklist));
    }

    @GetMapping("/{rgstrChklstId}")
    public ResponseEntity<ChecklistMapEntity> getById(@PathVariable String rgstrId, @PathVariable int rgstrChklstId) {
        return ResponseEntity.ok(checklistMapService.getById(rgstrChklstId));
    }

    @GetMapping
    public ResponseEntity<List<ChecklistMapEntity>> getByRegister(@PathVariable String rgstrId) {
        return ResponseEntity.ok(checklistMapService.getByRegisterId(rgstrId));
    }

    @DeleteMapping("/{rgstrChklstId}")
    public ResponseEntity<Void> delete(@PathVariable String rgstrId, @PathVariable int rgstrChklstId) {
        checklistMapService.delete(rgstrChklstId);
        return ResponseEntity.noContent().build();
    }
}
