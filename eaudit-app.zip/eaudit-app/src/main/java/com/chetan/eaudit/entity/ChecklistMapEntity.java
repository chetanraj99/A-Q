package com.chetan.eaudit.entity;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "EMMS_EAUDIT_RGSTR_CHKLST_MAP_TB", schema = "EAUDIT")
public class ChecklistMapEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RGSTR_CHKLST_ID")
    private int rgstrChklstId;

    @Column(name = "CHKLST_DESC")
    private String chklstDesc;

    @Column(name = "CHCKLST_AUTH_NO")
    private String chcklstAuthNo;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CHCKLST_AUTH_DATE")
    private Date chcklstAuthDate;

    @Column(name = "CHCKLST_RMRK")
    private String chcklstRmrk;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CRTD_ON")
    private Date crtdOn;

    @Column(name = "CRTD_BY")
    private String crtdBy;

    @ManyToOne
    @JoinColumn(name = "RGSTR_ID")
    private RegisterEntity register;

    public int getRgstrChklstId() { return this.rgstrChklstId; }
    public void setRgstrChklstId(int rgstrChklstId) { this.rgstrChklstId = rgstrChklstId; }

    public String getChklstDesc() { return this.chklstDesc; }
    public void setChklstDesc(String chklstDesc) { this.chklstDesc = chklstDesc; }

    public String getChcklstAuthNo() { return this.chcklstAuthNo; }
    public void setChcklstAuthNo(String chcklstAuthNo) { this.chcklstAuthNo = chcklstAuthNo; }

    public Date getChcklstAuthDate() { return this.chcklstAuthDate; }
    public void setChcklstAuthDate(Date chcklstAuthDate) { this.chcklstAuthDate = chcklstAuthDate; }

    public String getChcklstRmrk() { return this.chcklstRmrk; }
    public void setChcklstRmrk(String chcklstRmrk) { this.chcklstRmrk = chcklstRmrk; }

    public Date getCrtdOn() { return this.crtdOn; }
    public void setCrtdOn(Date crtdOn) { this.crtdOn = crtdOn; }

    public String getCrtdBy() { return this.crtdBy; }
    public void setCrtdBy(String crtdBy) { this.crtdBy = crtdBy; }

    public RegisterEntity getRegister() { return this.register; }
    public void setRegister(RegisterEntity register) { this.register = register; }
}
