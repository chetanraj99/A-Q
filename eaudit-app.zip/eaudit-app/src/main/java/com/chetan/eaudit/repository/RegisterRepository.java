package com.chetan.eaudit.repository;

import com.chetan.eaudit.entity.RegisterEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RegisterRepository extends JpaRepository<RegisterEntity, String> {

    Optional<RegisterEntity> findByRgstrDesc(String rgstrDesc);
}
