package com.chetan.eaudit.service;

import com.chetan.eaudit.entity.RegisterEntity;
import com.chetan.eaudit.entity.SecRegisterMappingEntity;
import com.chetan.eaudit.entity.SecRegisterMappingId;
import com.chetan.eaudit.exception.ResourceNotFoundException;
import com.chetan.eaudit.repository.SecRegisterMappingRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class SecRegisterMappingServiceImpl implements SecRegisterMappingService {

    private final SecRegisterMappingRepository mappingRepository;
    private final RegisterService registerService;

    public SecRegisterMappingServiceImpl(SecRegisterMappingRepository mappingRepository, RegisterService registerService) {
        this.mappingRepository = mappingRepository;
        this.registerService = registerService;
    }

    @Override
    @Transactional
    public SecRegisterMappingEntity create(String rgstrId, SecRegisterMappingEntity mapping) {
        RegisterEntity register = registerService.getById(rgstrId);
        mapping.getId().setRgstrId(rgstrId);
        mapping.setRegister(register);
        mapping.setCreatedOn(System.currentTimeMillis());
        return mappingRepository.save(mapping);
    }

    @Override
    public SecRegisterMappingEntity getById(SecRegisterMappingId id) {
        return mappingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Mapping not found: " + id));
    }

    @Override
    public List<SecRegisterMappingEntity> getByRegisterId(String rgstrId) {
        return mappingRepository.findByRegister_RgstrId(rgstrId);
    }

    @Override
    @Transactional
    public void delete(SecRegisterMappingId id) {
        mappingRepository.delete(getById(id));
    }
}
