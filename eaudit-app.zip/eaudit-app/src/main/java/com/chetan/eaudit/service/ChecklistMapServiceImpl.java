package com.chetan.eaudit.service;

import com.chetan.eaudit.entity.ChecklistMapEntity;
import com.chetan.eaudit.entity.RegisterEntity;
import com.chetan.eaudit.exception.ResourceNotFoundException;
import com.chetan.eaudit.repository.ChecklistMapRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class ChecklistMapServiceImpl implements ChecklistMapService {

    private final ChecklistMapRepository checklistMapRepository;
    private final RegisterService registerService;

    public ChecklistMapServiceImpl(ChecklistMapRepository checklistMapRepository, RegisterService registerService) {
        this.checklistMapRepository = checklistMapRepository;
        this.registerService = registerService;
    }

    @Override
    @Transactional
    public ChecklistMapEntity create(String rgstrId, ChecklistMapEntity checklist) {
        RegisterEntity register = registerService.getById(rgstrId);
        checklist.setRegister(register);
        checklist.setCrtdOn(new Date());
        return checklistMapRepository.save(checklist);
    }

    @Override
    @Transactional
    public ChecklistMapEntity update(int rgstrChklstId, ChecklistMapEntity updated) {
        ChecklistMapEntity existing = getById(rgstrChklstId);
        existing.setChklstDesc(updated.getChklstDesc());
        existing.setChcklstAuthNo(updated.getChcklstAuthNo());
        existing.setChcklstAuthDate(updated.getChcklstAuthDate());
        existing.setChcklstRmrk(updated.getChcklstRmrk());
        return checklistMapRepository.save(existing);
    }

    @Override
    public ChecklistMapEntity getById(int rgstrChklstId) {
        return checklistMapRepository.findById(rgstrChklstId)
                .orElseThrow(() -> new ResourceNotFoundException("Checklist item not found: " + rgstrChklstId));
    }

    @Override
    public List<ChecklistMapEntity> getByRegisterId(String rgstrId) {
        return checklistMapRepository.findByRegister_RgstrId(rgstrId);
    }

    @Override
    @Transactional
    public void delete(int rgstrChklstId) {
        checklistMapRepository.delete(getById(rgstrChklstId));
    }
}
