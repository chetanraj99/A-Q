package com.chetan.eaudit.service;

import com.chetan.eaudit.entity.RegisterEntity;

import java.util.List;

public interface RegisterService {

    RegisterEntity create(RegisterEntity register);

    RegisterEntity update(String rgstrId, RegisterEntity register);

    RegisterEntity getById(String rgstrId);

    List<RegisterEntity> getAll();

    void delete(String rgstrId);
}
