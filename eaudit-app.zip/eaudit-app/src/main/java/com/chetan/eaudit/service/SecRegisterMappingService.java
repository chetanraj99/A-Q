package com.chetan.eaudit.service;

import com.chetan.eaudit.entity.SecRegisterMappingEntity;
import com.chetan.eaudit.entity.SecRegisterMappingId;

import java.util.List;

public interface SecRegisterMappingService {

    SecRegisterMappingEntity create(String rgstrId, SecRegisterMappingEntity mapping);

    SecRegisterMappingEntity getById(SecRegisterMappingId id);

    List<SecRegisterMappingEntity> getByRegisterId(String rgstrId);

    void delete(SecRegisterMappingId id);
}
