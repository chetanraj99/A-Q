package com.chetan.eaudit.controller;

import com.chetan.eaudit.entity.SecRegisterMappingEntity;
import com.chetan.eaudit.entity.SecRegisterMappingId;
import com.chetan.eaudit.service.SecRegisterMappingService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/registers/{rgstrId}/section-mappings")
public class SecRegisterMappingController {

    private final SecRegisterMappingService mappingService;

    public SecRegisterMappingController(SecRegisterMappingService mappingService) {
        this.mappingService = mappingService;
    }

    @PostMapping
    public ResponseEntity<SecRegisterMappingEntity> create(@PathVariable String rgstrId,
                                                             @Valid @RequestBody SecRegisterMappingEntity mapping) {
        return new ResponseEntity<>(mappingService.create(rgstrId, mapping), HttpStatus.CREATED);
    }

    @GetMapping("/{secId}")
    public ResponseEntity<SecRegisterMappingEntity> getById(@PathVariable String rgstrId, @PathVariable String secId) {
        return ResponseEntity.ok(mappingService.getById(new SecRegisterMappingId(rgstrId, secId)));
    }

    @GetMapping
    public ResponseEntity<List<SecRegisterMappingEntity>> getByRegister(@PathVariable String rgstrId) {
        return ResponseEntity.ok(mappingService.getByRegisterId(rgstrId));
    }

    @DeleteMapping("/{secId}")
    public ResponseEntity<Void> delete(@PathVariable String rgstrId, @PathVariable String secId) {
        mappingService.delete(new SecRegisterMappingId(rgstrId, secId));
        return ResponseEntity.noContent().build();
    }
}
