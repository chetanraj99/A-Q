package com.chetan.eaudit.entity;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "EMMS_EAUDIT_RGSTR_TB", schema = "EAUDIT")
public class RegisterEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "RGSTR_ID", length = 30)
    private String rgstrId;

    @Column(name = "RGSTR_DESC", length = 100)
    private String rgstrDesc;

    @Column(name = "CREATED_ON")
    private long createdOn;

    @Column(name = "CREATED_BY", length = 50)
    private String createdBy;

    @Column(name = "AUTHORITY_NO", length = 10)
    private String authorityNo;

    @Column(name = "AUTHORITY_DATE")
    private long authorityDate;

    @Column(name = "REMARKS", length = 200)
    private String remarks;

    @OneToMany(mappedBy = "register", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<ChecklistMapEntity> checklistMaps = new HashSet<>();

    @OneToMany(mappedBy = "register", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<SecRegisterMappingEntity> secRegisterMappings = new HashSet<>();

    public String getRgstrId() { return this.rgstrId; }
    public void setRgstrId(String rgstrId) { this.rgstrId = rgstrId; }

    public String getRgstrDesc() { return this.rgstrDesc; }
    public void setRgstrDesc(String rgstrDesc) { this.rgstrDesc = rgstrDesc; }

    public long getCreatedOn() { return this.createdOn; }
    public void setCreatedOn(long createdOn) { this.createdOn = createdOn; }

    public String getCreatedBy() { return this.createdBy; }
    public void setCreatedBy(String createdBy) { this.createdBy = createdBy; }

    public String getAuthorityNo() { return this.authorityNo; }
    public void setAuthorityNo(String authorityNo) { this.authorityNo = authorityNo; }

    public long getAuthorityDate() { return this.authorityDate; }
    public void setAuthorityDate(long authorityDate) { this.authorityDate = authorityDate; }

    public String getRemarks() { return this.remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    public Set<ChecklistMapEntity> getChecklistMaps() { return this.checklistMaps; }
    public void setChecklistMaps(Set<ChecklistMapEntity> checklistMaps) { this.checklistMaps = checklistMaps; }

    public Set<SecRegisterMappingEntity> getSecRegisterMappings() { return this.secRegisterMappings; }
    public void setSecRegisterMappings(Set<SecRegisterMappingEntity> secRegisterMappings) { this.secRegisterMappings = secRegisterMappings; }
}
