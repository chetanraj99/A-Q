package com.chetan.eaudit.service;

import com.chetan.eaudit.entity.RegisterEntity;
import com.chetan.eaudit.exception.ResourceNotFoundException;
import com.chetan.eaudit.repository.RegisterRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class RegisterServiceImpl implements RegisterService {

    private final RegisterRepository registerRepository;

    public RegisterServiceImpl(RegisterRepository registerRepository) {
        this.registerRepository = registerRepository;
    }

    @Override
    @Transactional
    public RegisterEntity create(RegisterEntity register) {
        registerRepository.findByRgstrDesc(register.getRgstrDesc()).ifPresent(existing -> {
            throw new IllegalStateException("A register with this description already exists: " + register.getRgstrDesc());
        });
        register.setCreatedOn(System.currentTimeMillis());
        return registerRepository.save(register);
    }

    @Override
    @Transactional
    public RegisterEntity update(String rgstrId, RegisterEntity updated) {
        RegisterEntity existing = getById(rgstrId);
        existing.setRgstrDesc(updated.getRgstrDesc());
        existing.setAuthorityNo(updated.getAuthorityNo());
        existing.setAuthorityDate(updated.getAuthorityDate());
        existing.setRemarks(updated.getRemarks());
        return registerRepository.save(existing);
    }

    @Override
    public RegisterEntity getById(String rgstrId) {
        return registerRepository.findById(rgstrId)
                .orElseThrow(() -> new ResourceNotFoundException("Register not found: " + rgstrId));
    }

    @Override
    public List<RegisterEntity> getAll() {
        return registerRepository.findAll();
    }

    @Override
    @Transactional
    public void delete(String rgstrId) {
        RegisterEntity existing = getById(rgstrId);
        registerRepository.delete(existing);
    }
}
